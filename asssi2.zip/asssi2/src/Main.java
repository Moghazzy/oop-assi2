//public class Main {
    //public static void main(String[] args) {

       // MyInteger myinteger = new MyInteger(13);
        //myinteger.isEven();
        //myinteger.getValue();
        //myinteger.isOdd();
        //myinteger.isPrime();
        //System.out.println("  VALUE ENTERED IS  "+ myinteger.getValue());
        //System.out.println("is it even"+"\t"+myinteger.isEven());
        //System.out.println("is it odd"+"\t"+myinteger.isOdd());
        //System.out.println("is it prime"+"\t"+myinteger.isPrime());
       public class Main{
           public static void main(String[]args){
               B b= new B();
           }
       }

    //}
// }
// answer is(A'S NO ARG CONSTRUCTOR IS INVOKED///constructor A in class A cannot be applied to given types;
//  required: int
//  found: no arguments
//  reason: actual and formal argument lists differ in length)q6

//
//q7 //
//q8    override//
//q9    violates the rules of method overriding //