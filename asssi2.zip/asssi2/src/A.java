public class A {
    public A(int x){
        //System.out.println("A'S NO ARG CONSTRUCTOR IS INVOKED");

    }
}

class B extends A{
public B(){

}
}
